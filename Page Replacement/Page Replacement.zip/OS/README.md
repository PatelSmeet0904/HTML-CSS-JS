# Disk-scheduling-algorithms
It is the project of OS ( disk scheduling algorithm) in website.
IT consists of all the disk sheduling algoritms with input output of seek time and real time graph.
In this we are going to build website for visulization of the Operating System Disk Sceduling Algo.
